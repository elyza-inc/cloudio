# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cloudio']

package_data = \
{'': ['*']}

install_requires = \
['boto3>=1.12.46,<2.0.0', 'requests>=2.23.0,<3.0.0', 'tqdm>=4.45.0,<5.0.0']

setup_kwargs = {
    'name': 'cloudio',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Tomoaki Nakamura',
    'author_email': 'tomoaki.nakamura@elyza.ai',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
